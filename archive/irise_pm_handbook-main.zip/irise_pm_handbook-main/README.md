iRISE Project Management Handbook.

Available here: https://camaradesuk.github.io/irise_pm_handbook/.
